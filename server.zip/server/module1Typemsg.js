export let constant={
    msg_prive='s',
    msg_broadcast="b",
    msg_server="hello"

};